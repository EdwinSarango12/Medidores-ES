import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonList,
  IonItem,
  IonLabel,
  IonProgressBar,
} from '@ionic/angular/standalone';
import { ExpensesService } from '../services/expenses.service';
import { Expense } from '../models/expense';

@Component({
  selector: 'app-tab4',
  templateUrl: './tab4.page.html',
  styleUrls: ['./tab4.page.scss'],
  imports: [
    IonContent, IonHeader, IonTitle, IonToolbar,
    IonCard, IonCardHeader, IonCardTitle, IonCardContent,
    IonList, IonItem, IonLabel, IonProgressBar,
    CommonModule, FormsModule,
  ]
})
export class Tab4Page implements OnInit {
  expenses: Expense[] = [];
  startDate = '';
  endDate = '';
  currentMonth = new Date();

  constructor(private service: ExpensesService) {}

  async ngOnInit() {
    await this.service.load();
    this.expenses = this.service.list();
    const today = new Date();
    const start = new Date(today.getFullYear(), today.getMonth(), 1);
    this.startDate = this.toDateInput(start);
    this.endDate = this.toDateInput(today);
  }

  get filtered(): Expense[] {
    const s = new Date(this.startDate);
    const e = new Date(this.endDate);
    e.setHours(23,59,59,999);
    return this.expenses.filter(ex => {
      const d = new Date(ex.dateISO);
      return d >= s && d <= e;
    });
  }

  get total(): number {
    return this.filtered.reduce((sum, e) => sum + e.amount, 0);
  }

  get avgPerDay(): number {
    const s = new Date(this.startDate);
    const e = new Date(this.endDate);
    const days = Math.max(1, Math.ceil((e.getTime() - s.getTime()) / (1000*60*60*24)) + 1);
    return this.total / days;
  }

  get byCategory(): { name: string; amount: number }[] {
    const map = new Map<string, number>();
    for (const e of this.filtered) {
      map.set(e.category, (map.get(e.category) || 0) + e.amount);
    }
    return Array.from(map.entries()).map(([name, amount]) => ({ name, amount }))
      .sort((a,b) => b.amount - a.amount);
  }

  maxCategoryAmount(): number {
    return Math.max(1, ...this.byCategory.map(c => c.amount));
  }

  barColor(name: string): string {
    switch ((name || '').toLowerCase()) {
      case 'comida': return 'primary';
      case 'restaurantes': return 'tertiary';
      case 'transporte': return 'warning';
      case 'compras': return 'success';
      case 'salud': return 'danger';
      default: return 'medium';
    }
  }

  percentOfTotal(amount: number): number {
    const t = this.total;
    if (!t) return 0;
    return (amount / t) * 100;
  }

  private toDateInput(d: Date): string {
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth()+1).padStart(2,'0');
    const dd = String(d.getDate()).padStart(2,'0');
    return `${yyyy}-${mm}-${dd}`;
  }
}
