import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonItem,
  IonLabel,
  IonInput,
  IonSelect,
  IonSelectOption,
  IonChip,
  IonButton,
  IonTextarea,
  IonList,
  IonNote,
  IonIcon,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  ToastController
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { cameraOutline, documentTextOutline, saveOutline } from 'ionicons/icons';
import { CommonModule } from '@angular/common';
import { ExpensesService } from '../services/expenses.service';
import { Camera } from '@capacitor/camera';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss'],
  imports: [
    CommonModule,
    FormsModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonItem,
    IonLabel,
    IonInput,
    IonSelect,
    IonSelectOption,
    IonChip,
    IonButton,
    IonTextarea,
    IonList,
    IonNote,
    IonIcon,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardContent,
  ],
})
export class Tab3Page {
  description = '';
  amount: number | null = null;
  payer = '';
  participants: string[] = [];
  memo = '';
  photoPath: string | null = null;
  category = '';

  people = ['Edwin', 'Daniel', 'Kevin'];
  categories = ['Comida', 'Restaurantes', 'Transporte', 'Compras', 'Salud', 'Otro'];

  constructor(private expenses: ExpensesService, private toastCtrl: ToastController) {
    addIcons({ cameraOutline, documentTextOutline, saveOutline });
  }

  toggleParticipant(name: string) {
    if (this.participants.includes(name)) {
      this.participants = this.participants.filter((n) => n !== name);
    } else {
      this.participants = [...this.participants, name];
    }
  }

  async takePhoto() {
    try {
      const allowed = await this.ensureCameraPermission();
      if (!allowed) {
        const t = await this.toastCtrl.create({ message: 'Permiso de cámara denegado. Actívalo para tomar la foto.', duration: 1700, color: 'warning' });
        await t.present();
        return;
      }
      this.photoPath = await this.expenses.takeReceiptPhoto();
      const t = await this.toastCtrl.create({ message: 'Foto tomada', duration: 1200, color: 'success' });
      await t.present();
    } catch (e) {
      const t = await this.toastCtrl.create({ message: 'No se pudo tomar la foto', duration: 1500, color: 'danger' });
      await t.present();
    }
  }

  private async ensureCameraPermission(): Promise<boolean> {
    try {
      const status = await Camera.checkPermissions();
      if ((status as any).camera === 'granted') return true;
      const req = await Camera.requestPermissions();
      return (req as any).camera === 'granted';
    } catch {
      // En web o si no existe API, dejamos que Camera.getPhoto maneje el prompt
      return true;
    }
  }

  async save() {
    if (!this.description || !this.amount || !this.payer || this.participants.length === 0 || !this.photoPath) {
      const t = await this.toastCtrl.create({ message: 'Completa todos los campos y toma la foto', duration: 1500, color: 'warning' });
      await t.present();
      return;
    }

    const text = `Descripcion: ${this.description}\nMonto: ${this.amount}\nQuien pago: ${this.payer}\nParticipantes: ${this.participants.join(', ')}\nNotas: ${this.memo}`;
    const textFileName = await this.expenses.saveReceiptText(text);

    await this.expenses.add({
      description: this.description,
      amount: Number(this.amount),
      category: this.category || 'Otro',
      payer: this.payer,
      participants: this.participants,
      photoFileName: this.photoPath,
      textFileName,
    });

    this.reset();
    const t = await this.toastCtrl.create({ message: 'Gasto guardado con recibo', duration: 1500, color: 'success' });
    await t.present();
  }

  reset() {
    this.description = '';
    this.amount = null;
    this.payer = '';
    this.participants = [];
    this.memo = '';
    this.photoPath = null;
    this.category = '';
  }
}
