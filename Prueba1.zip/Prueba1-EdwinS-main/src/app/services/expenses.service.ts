import { Injectable } from '@angular/core';
import { Expense } from '../models/expense';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Directory, Encoding, Filesystem } from '@capacitor/filesystem';
import { Preferences } from '@capacitor/preferences';

const EXPENSES_KEY = 'expenses_list_v1';
const RECEIPTS_DIR = 'receipts';
const PHOTOS_DIR = 'photos';

@Injectable({ providedIn: 'root' })
export class ExpensesService {
  private expenses: Expense[] = [];

  async load(): Promise<Expense[]> {
    const { value } = await Preferences.get({ key: EXPENSES_KEY });
    this.expenses = value ? JSON.parse(value) : [];
    return this.expenses;
  }

  private generateId(): string {
    return 'exp_' + Math.random().toString(36).slice(2) + Date.now().toString(36);
  }

  list(): Expense[] {
    return this.expenses;
  }

  async add(expense: Omit<Expense, 'id' | 'dateISO'>): Promise<Expense> {
    const full: Expense = {
      ...expense,
      id: this.generateId(),
      dateISO: new Date().toISOString(),
    };
    this.expenses = [full, ...this.expenses];
    await Preferences.set({ key: EXPENSES_KEY, value: JSON.stringify(this.expenses) });
    return full;
  }

  async takeReceiptPhoto(): Promise<string> {
    await this.ensureReceiptsDir();
    const photo = await Camera.getPhoto({
      source: CameraSource.Camera,
      resultType: CameraResultType.Base64,
      quality: 80,
    });
    const fileName = `${RECEIPTS_DIR}/photo_${Date.now()}.jpeg`;
    await Filesystem.writeFile({
      path: fileName,
      data: photo.base64String ?? '',
      directory: Directory.Data,
    });
    return fileName;
  }

  async takeUserPhoto(): Promise<string> {
    await this.ensureDir(PHOTOS_DIR);
    const photo = await Camera.getPhoto({
      source: CameraSource.Camera,
      resultType: CameraResultType.Base64,
      quality: 80,
    });
    const fileName = `${PHOTOS_DIR}/photo_${Date.now()}.jpeg`;
    await Filesystem.writeFile({
      path: fileName,
      data: photo.base64String ?? '',
      directory: Directory.Data,
    });
    return fileName;
  }

  async saveReceiptText(content: string): Promise<string> {
    await this.ensureReceiptsDir();
    const fileName = `${RECEIPTS_DIR}/receipt_${Date.now()}.txt`;
    await Filesystem.writeFile({
      path: fileName,
      data: content,
      directory: Directory.Data,
      encoding: Encoding.UTF8,
    });
    return fileName;
  }

  async readText(path: string): Promise<string> {
    const file = await Filesystem.readFile({ path, directory: Directory.Data, encoding: Encoding.UTF8 });
    return file.data as string;
  }

  getPhotoSrc(filePath: string): string {
    return filePath;
  }

  async readImageAsDataUrl(path: string): Promise<string> {
    const file = await Filesystem.readFile({ path, directory: Directory.Data });
    const ext = path.toLowerCase().endsWith('.png') ? 'png' : 'jpeg';
    const base64 = typeof file.data === 'string' ? file.data : await this.blobToBase64(file.data);
    return `data:image/${ext};base64,${base64}`;
  }

  private async blobToBase64(blob: Blob): Promise<string> {
    return await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve((reader.result as string).split(',')[1] ?? '');
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  private async ensureReceiptsDir() {
    await this.ensureDir(RECEIPTS_DIR);
  }

  private async ensureDir(dir: string) {
    try {
      await Filesystem.mkdir({ path: dir, recursive: true, directory: Directory.Data });
    } catch (e) {
    }
  }
}
