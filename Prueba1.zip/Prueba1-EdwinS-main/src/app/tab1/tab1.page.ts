import { Component, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonList,
  IonItem,
  IonLabel,
  IonBadge,
  IonIcon,
  IonNote,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonButton,
  IonRefresher,
  IonRefresherContent
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { checkmarkCircleOutline } from 'ionicons/icons';
import { ExpensesService } from '../services/expenses.service';
import { Expense } from '../models/expense';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
  imports: [
    CommonModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonList,
    IonItem,
    IonLabel,
    IonBadge,
    IonIcon,
    IonNote,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardSubtitle,
    IonCardTitle,
    IonButton,
    IonRefresher,
    IonRefresherContent,
  ],
  providers: [DatePipe]
})
export class Tab1Page implements OnInit {
  expenses: Expense[] = [];
  totalMonth = 0;
  currentMonth = new Date();
  thumbMap: Record<string, string | null> = {};

  constructor(private service: ExpensesService, private datePipe: DatePipe) {
    addIcons({ checkmarkCircleOutline });
  }

  async ngOnInit() {
    await this.service.load();
    this.refresh();
    this.loadThumbs();
  }

  ionViewWillEnter() {
    this.refresh();
  }

  refresh() {
    this.expenses = this.service.list();
    const m = this.currentMonth.getMonth();
    const y = this.currentMonth.getFullYear();
    this.totalMonth = this.expenses
      .filter((e) => {
        const d = new Date(e.dateISO);
        return d.getMonth() === m && d.getFullYear() === y;
      })
      .reduce((sum, e) => sum + e.amount, 0);
    this.loadThumbs();
  }

  async handleRefresh(event: CustomEvent) {
    await this.service.load();
    this.refresh();
    const refresher = event.target as any;
    refresher.complete();
  }

  private async loadThumbs() {
    const promises = this.expenses.map(async (e) => {
      if (!e.photoFileName) { this.thumbMap[e.id] = null; return; }
      if (this.thumbMap[e.id]) return;
      try {
        const src = await this.service.readImageAsDataUrl(e.photoFileName);
        this.thumbMap[e.id] = src;
      } catch {
        this.thumbMap[e.id] = null;
      }
    });
    await Promise.all(promises);
  }
}
