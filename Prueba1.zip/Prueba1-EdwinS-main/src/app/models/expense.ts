export interface Expense {
  id: string;
  description: string;
  amount: number;
  category: string;
  payer: string;
  participants: string[];
  dateISO: string;
  photoFileName: string; 
  textFileName: string;  
}
