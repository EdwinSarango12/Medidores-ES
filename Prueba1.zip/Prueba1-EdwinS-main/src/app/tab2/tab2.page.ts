import { Component, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonGrid,
  IonRow,
  IonCol,
  IonLabel,
  IonIcon,
  IonNote,
  IonModal,
  IonButton,
  IonRefresher,
  IonRefresherContent,
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { documentTextOutline, searchOutline } from 'ionicons/icons';
import { ExpensesService } from '../services/expenses.service';
import { Expense } from '../models/expense';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss'],
  imports: [
    CommonModule,
    IonHeader, IonToolbar, IonTitle, IonContent,
    IonCard, IonCardHeader, IonCardTitle, IonCardContent,
    IonGrid, IonRow, IonCol, IonLabel, IonIcon, IonNote, IonModal, IonButton,
    IonRefresher, IonRefresherContent,
  ],
  providers: [DatePipe]
})
export class Tab2Page implements OnInit {
  expenses: Expense[] = [];
  selected?: Expense;
  previewSrc: string | null = null;
  showModal = false;

  constructor(private service: ExpensesService, private datePipe: DatePipe) {
    addIcons({ documentTextOutline, searchOutline });
  }

  async ngOnInit() {
    await this.service.load();
    this.expenses = this.service.list();
  }

  async openDetail(e: Expense) {
    this.selected = e;
    try {
      this.previewSrc = await this.service.readImageAsDataUrl(e.photoFileName);
    } catch {
      this.previewSrc = null;
    }
    this.showModal = true;
  }

  closeDetail() {
    this.showModal = false;
    this.selected = undefined;
    this.previewSrc = null;
  }

  async handleRefresh(event: CustomEvent) {
    await this.service.load();
    this.expenses = this.service.list();
    const refresher = event.target as any;
    refresher.complete();
  }
}
