# Prueba1 — App de Gastos con Recibos (Ionic Angular)

Desarrollado por: Edwin Sarango
Aplicación de ejemplo en Ionic Angular para registrar gastos con soporte de fotos de recibos, almacenamiento local y visualización en lista y galería.

## APK
[APK](app-debug.apk)

## Estructura principal
- `src/app/services/expenses.service.ts`: Lógica de datos, cámara y archivos.
- `src/app/models/expense.ts`: Modelo de datos `Expense`.
- `src/app/tab1/`: Tab de listado y totales.
- `src/app/tab2/`: Tab de galería y detalle de recibo.

## Servicio: `ExpensesService`
Archivo: `src/app/services/expenses.service.ts`

- `async load(): Promise<Expense[]>`
  - Lee `expenses_list_v1` desde Capacitor Preferences y carga en memoria.
  - Devuelve la lista en memoria.
  - Genera `id` y `dateISO`, guarda en Preferences y retorna el gasto creado.
  - Abre cámara (Capacitor Camera), guarda imagen en `Data/receipts/` y retorna la ruta.
  - Similar a `takeReceiptPhoto` pero guarda en `Data/photos/`.
  - Crea un `.txt` en `Data/receipts/` con el contenido.
  - Lee un archivo de texto desde el almacenamiento interno.
  - Retorna la ruta tal cual (helper para usar como `src`).
  - Lee binario y entrega un `data:image/...;base64,...` listo para `<img>`.

## Tab 1 — Lista y Totales
Ruta: `src/app/tab1/`

- **Componentes clave**: `tab1.page.ts`, `tab1.page.html`
- **Funcionalidad**:
  - Muestra un resumen de "Total gastado" del mes actual.
  - Lista de gastos con descripción, monto, pagador, fecha y participantes.
  - Miniatura del recibo si existe.
  - "Recibo verificado" (icono) para indicar que existe foto asociada.
  - Refresher (pull-to-refresh) para recargar datos y miniaturas.

![inicio](https://github.com/user-attachments/assets/33689e97-6ca3-4531-bc1c-f9063acd7c74)

## Tab 2 — Galería y Detalle de Recibo
Ruta: `src/app/tab2/`

- **Componentes clave**: `tab2.page.ts`, `tab2.page.html`
- **Funcionalidad**:
  - Tarjeta de conteo: número de recibos registrados.
  - Galería con cada gasto y botón para ver detalle.

![9cab387f-439b-48ea-bb2c-7eccd95d96be](https://github.com/user-attachments/assets/937a3f03-cd85-4b1a-a83f-a7eafd6c15bb)

## Tab 3 — Nuevo recibo
Ruta: `src/app/tab3/`
- **Componentes clave**: `tab3.page.ts`, `tab3.page.html`
- **Funcionalidad**:
  - Espacio para agregar datos de nuevo recibo.
  - Implementación de `@capacitor/camera` para agregar una foto como recibo o evidencia.

![recibo](https://github.com/user-attachments/assets/f3d2fdd4-d7d8-4e75-8e91-ec04a94ea03d)

## Instalación y ejecución
1. Instalar dependencias
   ```bash
   npm install -g @ionic/cli
   ```
2. Ejecutar en navegador
   ```bash
   ionic serve
   ```
3. Plataformas nativas (opcional)
   ```bash
   npx cap add android
   npm run build
   npx cap sync android
   npx cap open android
   ```

## Permisos y consideraciones
- **Cámara**: en Android/iOS, asegúrate de configurar permisos de cámara en los proyectos nativos abiertos con Capacitor.
- **Almacenamiento**: se usa `Directory.Data` (privado de la app). Los archivos no aparecen en galería del sistema.
- **Preferencias**: `Preferences` guarda la lista de gastos en `expenses_list_v1`.

<img width="323" height="275" alt="image" src="https://github.com/user-attachments/assets/4dab2f3a-4509-4b66-992f-06ae74c3fc06" />

